package com.example.historicalsites;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HistoricalsitesApplicationTests {

	@Test
	void contextLoads() {
	}

}
