package com.example.historicalsites;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HistoricalsitesApplication {

	public static void main(String[] args) {
		SpringApplication.run(HistoricalsitesApplication.class, args);
	}

}
